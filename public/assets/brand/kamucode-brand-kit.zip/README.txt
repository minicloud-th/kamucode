kamucode

All logo artwork has a transparent background.
logo: for light backgrounds
logo-dark: for dark backgrounds
mark: standalone symbol
wordmark: lettering only
logo-mono / logo-white: single-color versions
SVG: scalable vector paths, no font installation required
PNG: transparent exports, 2520 px wide; symbols 1024 px
