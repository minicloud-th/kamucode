kamucode / Ribbon Star

Original layered ribbon symbol for kamucode.
The existing kamucode wordmark paths and typeface are preserved.

SVG files are scalable native vectors.
PNG symbol exports: 1024 x 1024, transparent.
PNG logo exports: 2520 x 384, transparent.
mark-preview.png: 384 x 384, transparent.
logo.svg / mark.svg: light backgrounds.
logo-dark.svg / mark-dark.svg: dark backgrounds.
logo-mono.svg / logo-white.svg: monochrome variants.
favicon.svg supports light and dark browser themes.

Geometry source in the repository: lib/brand-symbol.mjs
SVG regeneration: node scripts/refresh-brand-assets.mjs
Brand opening animation: components/ui/brand-intro.tsx
